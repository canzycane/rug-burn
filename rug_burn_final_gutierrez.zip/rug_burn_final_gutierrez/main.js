"use strict"

const express = require("express"),
app = express(),
errorController = require("./controllers/errorController"),
homeController = require("./controllers/homeController"),
subscribersController = require("./controllers/subscribersController"),
layouts = require("express-ejs-layouts"),
mongoose = require("mongoose"),
Subscriber = require("./models/subscriber");

mongoose.connect("mongodb+srv://canzycane:theBlueHouse01!@cluster0.jgapuyo.mongodb.net/Cluster0?retryWrites=true&w=majority&appName=Cluster0"); 

const db = mongoose.connection;

db.once("open", () => {
    console.log("Connected to MongoDB");
});

app.set("port", process.env.PORT || 3000);
app.set("view engine", "ejs");

app.use(express.static("public"));
app.use(layouts);
app.use(
    express.urlencoded({
        extended: false
    })
);
app.use(express.json());
app.use(homeController.logRequestPaths);

app.get("/", homeController.index);
app.get("/rugs", homeController.rugs);
app.get("/faqs", homeController.faqs);
app.get("/about", homeController.about);
app.get("/contact", subscribersController.getSubscriptionPage);
app.get("/subscribers", subscribersController.getAllSubscribers, (req, res, next) => {
    res.render("subscribers", {subscribers: req.data});
});
app.post("/subscribe", subscribersController.saveSubscriber);


app.use(errorController.noPageFound);
app.use(errorController.respondInternalError);

app.listen(app.get("port"), () => {
    console.log(`Server running at http://localhost:${app.get("port")}`);
});