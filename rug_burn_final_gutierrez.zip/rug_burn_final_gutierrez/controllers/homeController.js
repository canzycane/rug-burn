exports.logRequestPaths = (req, res, next) => {
    console.log(`request made to: ${req.url}`);
    next();
}; 


exports.index = (req, res) => {
    res.render("index");
};
exports.rugs = (req, res) => {
    res.render("rugs");
};
exports.faqs = (req, res) => {
    res.render("faqs");
};
exports.contact = (req, res) => {
    res.render("contact");
};
exports.about = (req, res) => {
    res.render("about");
};

exports.showSignUp = (req, res) => {
    res.render("contact");
};

exports.postedSignUpForm = (req, res) => {
    res.render("thanks");
};
